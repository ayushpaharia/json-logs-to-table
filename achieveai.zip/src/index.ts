#!/usr/bin/env node

import fs from "fs"
const file_data = fs.readFileSync(process.argv[2], "utf8")

console.clear()

const isPrefixEmpty = (prefix: string, key: string): string => {
  // If prefix is empty(when first element)
  return prefix === "" ? key : `${prefix}.${key}`
}

const columns = new Set() // To keep a check of how many columns were created
const makeColumn = (obj_data: any, prefix_string: string) => {
  Object.entries(obj_data).forEach(([key, value]) => {
    const prefix = isPrefixEmpty(prefix_string, key)
    if (value !== null && typeof value === "object") {
      makeColumn(value, prefix)
    } else {
      columns.add(prefix)
      let stream = fs.createWriteStream(`./logs/${prefix}.column`, {
        flags: "a",
      })
      // Streams are non-blocking and is hence good for working with huge log files
      stream.once("open", () => {
        stream.write(`${value}\n`)
        stream.end()
      })
    }
  })
}

const proccesLogs = (data: string) => {
  // parse JSON from a log
  const obj_data = JSON.parse(data)

  // Make columns
  makeColumn(obj_data, "")
}

// split the log file into an array of lines and process everyline
file_data.split("\r\n").forEach(proccesLogs)

console.log(
  "Following files were created\n",
  [...columns].map((column) => `${column}.column`),
)
