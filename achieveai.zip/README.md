# Huge JSON files to Columns

## How to use

 Install and build the app
```
npm install && npm run build
```

then give executable permissions to the `dist/index.js` file

```
chmod +x ./dist/index.js
```

And finally to run you can do
```
./dist/index.js <path-to-your-log-file>
```